# MoE-CTS test arşivi — neyin ne olduğu

Bu klasör, `go2_moects` (MoE-CTS) kolu üzerinde yapılan bütün ölçüm kampanyalarının
tek giriş noktası. **İçindeki her şey göreli symlink'tir** — dosyaların gerçek yeri
repodaki orijinal konumları; burada kopya yok, dolayısıyla bayatlama da yok.
Bir raporu düzenlersen orijinali düzenlemiş olursun.

Kapsam: `go2_moects` / `ActorCriticMoECTS` / `PPO_MOE_CTS`.
Birincil koşu: `logs/go2_moects/Aug03_12-01-45_moe_cts_genesis` (Go2, 8 uzman, 32-D latent).
Karşılaştırma tarafı: wty-yy `go2_rl_gym` upstream'inin yayımlanmış deployment-bridge
checkpoint'leri (137k ve 164k), arXiv:2602.00678.

---

## Tek cümlelik durum

Uzmanlaşma iddiası iki bağımsız protokolde de tutmuyor — ne bizim Genesis portumuzda
ne de upstream'in kendi yayımlanmış checkpoint'lerinde gate seyrek ya da terrain-semantik
routing gösteriyor. Latent gerçekten kullanılıyor ve içinde fizik bilgisi var, ama bu bilgi
**eğitimle kazanılmıyor** (rastgele init encoder'la aynı seviyede). Detaylar
`01_raporlar/latent_probing_rapor.md` ve `01_raporlar/uzmanlasma_bizim_vs_upstream.md`.

---

## 01_raporlar — anlatı raporları (buradan başla)

Okuma sırası yukarıdan aşağı.

| dosya | ne anlatıyor |
|---|---|
| `uzmanlasma_bizim_vs_upstream.md` | **Ana sentez.** Bizim gate probe'umuz vs upstream MuJoCo sonuçları, metrik sözlüğü, makalenin kendi gerekçesinin analizi (§6–§8). Uzmanlaşma sorusunun toplu cevabı. |
| `latent_probing_rapor.md` | **Latent probing sonuç raporu.** ΔR² metodolojisi, sızıntı kontrolleri, düzeltilen iki ölçüm hatası, 4 ana bulgu. Faz A + Faz B'nin okunabilir özeti. |
| `uzmanlasma_upstream_mujoco.md` | Upstream 137k/164k checkpoint'lerinin MuJoCo closed-loop ölçümü. Checkpoint SHA256'ları, JIT parity kanıtı, provenance sınırları (teacher/critic yok — uydurulmadı). |
| `kod_karsilastirma_upstream_vs_bizim.md` | Upstream implementasyon (X) vs bizim port (Y) satır satır fark listesi. Effective config değerleri üzerinden; constructor default'ları değil. |
| `kurtarma_plani.md` | Aşamalı kurtar-ya-da-erken-öldür planı. §0'daki canlı takip tablosu iş paketlerinin durumunu (`PASS`/`STOP`/`BLOCKED`…) tutuyor — **kampanya durumu için önce buraya bak.** |
| `brake_probe_rapor.md` | MuJoCo'da hızlı duruş sonrası arka bacak kalkması: sim-to-sim farkın ölçümü, ölçümden önce düzeltilmesi gereken reset randomizasyonu. |
| `mimari_tartisma_notu.md` | Serbest biçimli mimari notu: bütün uzmanların tek teacher latent'ine eşlenmesi sorunu, dense privileged teacher + proprioceptive MoE student fikri. |

---

## 02_uzmanlasma — gate/routing kampanyası (ham çıktı)

**Soru:** 8 uzman gerçekten uzmanlaşıyor mu, gate anlamlı routing yapıyor mu?

- `bizim_gate_probe_model7500/` — Genesis bankası, N=35.328, DR açık (eğitim sadakati).
  - `REPORT.md` — M1–M6 metriklerinin yorumlu özeti. Hangi hipotezin devrildiği burada yazılı.
  - `results.json` — metriklerin ham hali, `meta.json` — provenance, `samples.pt` — banka.
  - `m1_effective_routing.png`, `m4_gate_ablation.png` — figürler.
  - Özet: routing neredeyse uniform (effective experts 7.46 → 6.04), uzmanlar **işlevsel olarak
    farklı** (off-diag cos 0.28), gate gerçekten yardım ediyor (learned 0.47 < uniform 0.75),
    ama terrain `obs_history`'den gözlemlenebilir **değil** (val acc 0.254 = majority 0.254) —
    yani "her terrain'e bir uzman" hedefi bu gözlem uzayında fiziksel olarak imkânsız.
- `upstream_mujoco/` — upstream 137k ve 164k, resmî `go2_rl_gym` MuJoCo hattı, exact flat+stairs.
  - Her checkpoint altında `jit_parity/metrics.json` (parity PASS kanıtı) ve
    `closed_loop_exact_flat_stairs/{metrics.json,probe.npz}` (264 rollout).
  - Özet: effective experts 6.53 / 6.62, mean max gate 0.288 / 0.291 — upstream de diffuse.

## 03_latent_probing — latent ne kodluyor kampanyası

**Soru A:** latent gizli fiziği (sürtünme, ek kütle, COM) kodluyor mu?
**Soru B:** actor bu latent'i gerçekten okuyor mu?

Ölçüt ham R² değil **ΔR² = R²(gözlem+latent) − R²(gözlem)** — latent'in gözlemin üstüne
kattığı bilgi. Veri doğal DR bankası değil, **kontrollü fizik gridi**: her seferinde tek
eksen süpürülür, diğer beşi tam sabit (6 eksen × 6 komut × 12 değer × 8 env = 92.160 satır).

- `phaseA_23500_ve_best_tracking/`
  - `model_23500/`, `best_tracking/` — `samples.npz` + `meta.json` bankaları.
  - `intervene_friction_hi|friction_lo|pdgain_hi/intervene.npz` — nedensel müdahale bankaları
    (51.200 satır/banka; modlar: `student`, `teacher_true`, `shuffled_matched`, `wrong_regime`).
  - `analysis/` ve **`analysis_fixed/`** — ⚠️ `analysis/` düzeltme öncesi hattan geliyor
    (bozuk fold ayrımı + seyreltilmiş hedef). **Geçerli sayılar `analysis_fixed/` içindedir.**
- `phaseB_checkpoint_trendi/` — aynı protokol, iter 500 / 2.500 / 7.500 / 12.500 (+ faz A'nın
  20.500 ve 23.500'ü) → 6 checkpoint'lik trend. `analysis/<model>/{REPORT.md,probe_metrics.json,
  delta_r2_heatmap.png}` ve `analysis/checkpoint_trend.png`.
- `paper_pca/` + `paper_pca.zip` — makaledeki PCA görselinin bizim checkpoint'lerde yeniden
  üretimi (`command_pca.*`, `terrain_pca.*`).

Her `REPORT.md`'nin başında **sızıntı kontrol kapısı** var (shuffled label ve random-init
encoder ΔR²'si ≈ 0). Kapı PASS değilse o rapordaki sayıları kullanma.

## 04_brake — sim-to-sim fren kampanyası

`veri/` — Genesis ve MuJoCo tarafında 144 koşullu (vx × duruş rampası × gait fazı) kayıt.
`campaign.log` + `replay.log` koşu kütüğü; `*_student/teacher/selfreplay/*.npz` ham zaman
serileri; `*_replay_*_sync|trig.npz` açık-döngü replay merdiveni.
Politika: `Aug03_12-01-45_moe_cts_genesis`, `model_20500.pt`.
Yorum `01_raporlar/brake_probe_rapor.md`'de.

---

## 05_kod — bu sayıları üreten kod

- `probe_scriptleri/` — kayıt ve analiz birbirinden ayrık: `probe_moe_gate.py`,
  `probe_moe_latent.py`, `probe_upstream_moe_cts.py`, `brake_probe.py` toplar;
  `probe_moe_analyze.py`, `brake_analyze.py`, `plot_moe_latent_pca.py` çevrimdışı türetir.
  Yani bir tanım değişince rollout'ları yeniden koşmak gerekmiyor.
  `probe_lib.py` ortak yardımcılar, `dr_axes.py` fizik ekseni tanımları,
  `run_brake_probe.sh` / `run_brake_replay.sh` kampanya sürücüleri.
- `implementasyon/` — ölçülen sistemin kendisi: `actor_critic_moe_cts.py`, `moe_utils.py`,
  `moe_terrain_gate.py`, `ppo_moe_cts.py`, `rollout_storage_moe_cts.py`, `moe_cts_runner.py`,
  `env_go2_moects/` (env + config).
- `testler/` — 27 sözleşme/regresyon testi. Env tarafı (`test_moects_*`: storage contract,
  role interleave, terrain gate, curriculum ratios, DR eksenleri…) ve probe tarafı
  (`test_moe_gate_probe.py`, `test_probe_moe_analyze_gate.py`, `test_probe_upstream_moe_cts.py`).
  Probe hattına dokunmadan önce bunları koştur.

## 06_kaynak_notlar — arka plan

- `wiki_moe_cts_parametreleri.md` — portun koddan derlenmiş tam parametre envanteri (2026-08-04
  checkout'u). Bir sayının nereden geldiğini ararken ilk bakılacak yer.
- `wiki_probe_planlari.md` — probe kampanyalarının planlama notları.
- `uhem_runbook.md` + `uhem_provenance.py` — UHeM/Altay üzerinde koşturma yordamı ve
  provenance kaydı.

## 07_checkpoint_ve_tb — ağırlıklar ve eğitim eğrileri

- `birincil_kosu_Aug03_12-01-45/` — bütün kampanyaların dayandığı koşu; `model_*.pt`
  checkpoint'leri ve TensorBoard event'leri.
- `upstream_bridge_137k/`, `upstream_bridge_164k/` — upstream deployment-bridge ağırlıkları.
  ⚠️ Bunlar **yalnız actor + student MoE** içeriyor; teacher/critic sadece rastgele
  initialization. `teacher_available=false`, `critic_available=false` sınırı korunmalı —
  bu checkpoint'lerden teacher latent'i veya privileged oracle üretme.
- `tb_merged_0_to_23540/` — 0→23.540 iter birleşik TensorBoard kütüğü (255 MB).
- `moects_7500_tb.json` — 7500 checkpoint'i için çıkarılmış skaler dökümü.

---

## Kapsam dışı (kasten)

- `logs/eval/probe/` — oracle/RMA karşı-olgusal probe'ları, v3 kampanyasına ait, MoE değil.
- `logs/go2_moects/` altındaki ~80 kısa `Aug04–Aug06` koşusu — smoke/lifecycle denemeleri,
  ölçüm verisi taşımıyor. Sadece birincil koşu ve upstream bridge'ler linklendi.
- `go2_moects_him` karşılaştırma kolu — ayrı bir çalışma (bkz. `wiki/HIM.md`).

## Bakım

Yeni bir kampanya bittiğinde: sonucu orijinal yerine yaz, buraya symlink ekle, bu dosyada
ilgili bölüme bir satır düş. Kırık link kontrolü:

```bash
find genesis-wp/LeggedGym-Ex/moe_cts -xtype l
```
